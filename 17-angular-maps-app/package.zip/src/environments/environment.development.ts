
export const environment = {
  mapboxKey: "pk.eyJ1IjoiYWx1Y2FyZDk4IiwiYSI6ImNtczR4N2xjNTAwY2YyeG9nbDFyNHBxZnIifQ.ianDU8EzbPWMO7yU5pWLEg"
};
